import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

const AUTH_API = 'http://localhost:8090/api/movies';



@Injectable({
  providedIn: 'root'
})
export class MovieService {
 

  constructor(private http: HttpClient) { }
  
  getMovies(): Observable<any> {
      return this.http.get(AUTH_API);
    }
}
